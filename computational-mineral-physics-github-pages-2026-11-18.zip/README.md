# Computational Mineral Physics Laboratory website

Static website for the Computational Mineral Physics Laboratory at Princeton University.

## Publishing

The repository root on the `codex/lab-website` branch is the GitHub Pages publishing source. In **Settings → Pages**, choose **Deploy from a branch**, then select `codex/lab-website` and `/ (root)`. The previous personal website remains on `master`. This site uses relative links and works at both the repository Pages URL and a custom domain.

Do not add a `CNAME` file until Princeton Web Development Services is ready to change DNS for `deng.princeton.edu`. At that point, set the GitHub Pages custom domain to `deng.princeton.edu`, commit a root `CNAME` file containing exactly that hostname, and ask Princeton to replace the existing DNS record with a CNAME to `neojie.github.io`. Turn on **Enforce HTTPS** once GitHub provisions the certificate.

The previous Drupal site should remain available or be archived. This package includes redirects for the current top-level routes, 2023 onward publication details, and linked news entries. Unknown older detail routes fall back to the relevant listing page.

## Site content

- `index.html`: homepage
- `people.html`, `jie-deng.html`: team and PI profile
- `research/`: overview and three research directions
- `publications.html`: 2023 onward papers and official DOI links
- `courses.html`, `opportunities.html`, `news.html`: other pages
- `assets/`: local images, diagrams, CV, and scripts

Before changing the Princeton domain, verify every page at the GitHub Pages URL and confirm that Princeton permits external hosting of this university-branded site.
