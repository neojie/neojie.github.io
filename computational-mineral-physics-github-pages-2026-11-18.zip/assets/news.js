const buttons = [...document.querySelectorAll('.news-filters button')];
const entries = [...document.querySelectorAll('.news-timeline .news-item')];
const years = [...document.querySelectorAll('.news-year')];
const count = document.querySelector('#news-count');

for (const button of buttons) {
  button.addEventListener('click', () => {
    const filter = button.dataset.filter;
    for (const item of buttons) item.setAttribute('aria-pressed', String(item === button));
    let visible = 0;
    for (const entry of entries) {
      const show = filter === 'all' || entry.dataset.category === filter;
      entry.hidden = !show;
      if (show) visible++;
    }
    for (const year of years) {
      const hasVisible = [...year.querySelectorAll('.news-item')].some(entry => !entry.hidden);
      year.hidden = !hasVisible;
      const jump = document.querySelector(`.news-year-jump a[href="#${year.id}"]`);
      if (jump) jump.hidden = !hasVisible;
    }
    count.textContent = `${visible} update${visible === 1 ? '' : 's'}`;
  });
}
